package mx.edu.ittepic.practica1_u3_circulosquerebotan;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class Lienzo extends View {
    Circulo c1, c2, c3, c4, c5;

    public Lienzo(Context context) {
        super(context);

        c1 = new Circulo(100, 100, this, Color.WHITE, 100);
        c2 = new Circulo(290, 290, this, Color.BLACK, 100);
        c3 = new Circulo(600, 400, this, Color.GRAY, 100);
        c4 = new Circulo(300, 300, this, Color.WHITE, 100);
        c5 = new Circulo(900, 900, this, Color.BLACK, 100);

        c1.movemiento(20, 20);
        c2.movemiento(50, 50);
        c3.movemiento(10, 10);
        c4.movemiento(100, 100);
        c5.movemiento(100, 10);

    }

    @Override
    public void onDraw(Canvas c) {

        Paint p = new Paint();
        c.drawColor(Color.MAGENTA);
        c1.pintar(c, p);
        c2.pintar(c, p);
        c3.pintar(c, p);
        c4.pintar(c, p);
        c5.pintar(c, p);

    }
}
