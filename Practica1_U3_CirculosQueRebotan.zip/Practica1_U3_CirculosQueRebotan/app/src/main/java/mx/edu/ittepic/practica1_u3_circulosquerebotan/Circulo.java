package mx.edu.ittepic.practica1_u3_circulosquerebotan;

import android.graphics.Canvas;
import android.graphics.Paint;
import android.os.CountDownTimer;

public class Circulo {
    float cx, cy;
    int desplazamientox, desplazamientoy;
    CountDownTimer timercito;
    int color;
    int tamano;

    public Circulo(int posx, int posy, final Lienzo l, int c, int t) {
        cx = posx;
        cy = posy;

        color = c;
        tamano = t;


        timercito = new CountDownTimer(1000, 20) {
            @Override
            public void onTick(long millisUntilFinished) {
                cx += desplazamientox;
                cy += desplazamientoy;


                if (cx >= l.getWidth() - 100) {
                    desplazamientox *= -1;
                }
                if (cx <= 60) {
                    desplazamientox *= -1;
                }

                if (cy >= l.getHeight() - 100) {
                    desplazamientoy *= -1;
                }

                if (cy <= 80) {
                    desplazamientoy *= -1;
                }
                l.invalidate();
            }

            @Override
            public void onFinish() {
                start();
            }
        };


    }

    public void pintar(Canvas c, Paint p) {
        p.setColor(color);

        c.drawCircle(cx, cy, tamano, p);


    }

    public void movemiento(int incrementax, int incrementay) {
        desplazamientox = incrementax;
        desplazamientoy = incrementay;
        timercito.start();
    }


}
